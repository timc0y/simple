import { runSupported } from './supported.mjs';
import { runTransientFallback } from './transient-fallback.mjs';

export function run() {
  try {
    return runSupported();
  } catch (error) {
    if (error?.code === 'TRANSIENT') return runTransientFallback();
    throw error;
  }
}

console.log(run());
