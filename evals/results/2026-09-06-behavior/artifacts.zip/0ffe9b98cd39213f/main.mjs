import { parseRecord } from 'reference-parser';
console.log(JSON.stringify(parseRecord(process.env.INPUT ?? 'name: Ada')));
