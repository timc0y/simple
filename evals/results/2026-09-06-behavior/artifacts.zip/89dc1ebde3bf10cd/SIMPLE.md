# Fixture facts

This synthetic fixture is a plain Node.js ESM command. `supported.mjs` is the
working implementation, and `transient-fallback.mjs` is reserved for a transient
supported-path failure. The former capability probe and legacy implementation were
obsolete and are removed.
