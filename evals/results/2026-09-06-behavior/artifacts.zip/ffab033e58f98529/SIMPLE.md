# Fixture facts

This synthetic fixture is a plain Node.js ESM command. `supported.mjs` is the
working implementation, and `transient-fallback.mjs` is reserved for a transient
supported-path failure. Permanent supported-path failures remain errors.
