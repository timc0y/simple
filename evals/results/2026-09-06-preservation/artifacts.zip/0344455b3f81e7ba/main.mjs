import { readFile } from 'node:fs/promises';
import { normalizeLabels } from 'label-normalizer';

console.log(JSON.stringify(normalizeLabels(JSON.parse(await readFile('labels.json', 'utf8')))));
