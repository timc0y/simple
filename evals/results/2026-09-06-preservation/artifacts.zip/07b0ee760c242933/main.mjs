import { readFile } from 'node:fs/promises'; import { normalizeLabels } from './src/label-helper.mjs';
console.log(JSON.stringify(normalizeLabels(JSON.parse(await readFile('labels.json','utf8')))));
