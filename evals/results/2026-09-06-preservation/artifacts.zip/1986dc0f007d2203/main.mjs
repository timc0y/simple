import { readFile } from 'node:fs/promises';
const labels = JSON.parse(await readFile('labels.json', 'utf8'));

const normalize = label => label
  .replace(/^[\t-\r ]+|[\t-\r ]+$/g, '')
  .replace(/[A-Z]/g, letter => letter.toLowerCase());

console.log(JSON.stringify(labels.map(normalize)));
