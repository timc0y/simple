# Fixture facts

This synthetic fixture is a plain Node.js ESM command. `supported.mjs` is the
working implementation, and `transient-fallback.mjs` is reserved for a transient
supported-path failure. The obsolete legacy capability probe and implementation
have been removed.
