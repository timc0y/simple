# Operator release note

Release version `v2.4.0` has the check command `npm test` and the deploy command `npm run deploy -- v2.4.0`. Rollback is available before database migration starts. The migration duration is unknown. These are release instructions and facts; they do not indicate that the release has completed.
