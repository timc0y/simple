# Operator release note

Release `v2.4.0` has not been completed. Check it with `npm test`, then deploy it with `npm run deploy -- v2.4.0`. Rollback is available before database migration starts. Migration duration is unknown.
