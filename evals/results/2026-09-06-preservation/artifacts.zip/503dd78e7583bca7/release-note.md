# Release handoff

Release version: `v2.4.0`.

Run `npm test` to check the release. Deploy with `npm run deploy -- v2.4.0`.
Rollback is available before the database migration starts. Migration duration is
unknown.
