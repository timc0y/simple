import { readFile } from 'node:fs/promises';
const labels = JSON.parse(await readFile('labels.json', 'utf8'));
const asciiTrim = value => value.replace(/^[\t\n\v\f\r ]+|[\t\n\v\f\r ]+$/g, '');
const asciiLowercase = value => value.replace(/[A-Z]/g, letter => letter.toLowerCase());

console.log(JSON.stringify(labels.map(label => asciiLowercase(asciiTrim(label)))));
