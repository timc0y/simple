# Fixture facts

This synthetic fixture is a plain Node.js ESM command. `supported.mjs` is the
working implementation, and `transient-fallback.mjs` handles a transient
supported-path failure. `main.mjs` owns runtime selection and rethrows permanent
errors.
