# Operator release note

Release `v2.4.0` has not been deployed. Run `npm test` as the check, then deploy with
`npm run deploy -- v2.4.0`. The rollback boundary is before database migration starts.
Migration duration is unknown.
