export function makeEvent(input) {
  const summary = `${input.actor.displayName} ${input.action} ${input.target}.`;
  return { actor: input.actor, action: input.action, target: input.target,
    summary,
    retentionDays: input.retentionDays, createdAt: input.createdAt };
}
export function describeEvent(event) { return event.summary; }
export function byActor(events, id) { return events.filter(e => e.actor.id === id); }
export function prune(events, now) {
  return events.filter(e => now - e.createdAt < e.retentionDays * 86400000);
}
