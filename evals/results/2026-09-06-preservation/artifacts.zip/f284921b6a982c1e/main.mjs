import { readFile } from 'node:fs/promises';
const labels = JSON.parse(await readFile('labels.json', 'utf8'));
const asciiWhitespace = /^[\t\n\v\f\r ]+|[\t\n\v\f\r ]+$/g;
const asciiUppercase = /[A-Z]/g;

console.log(JSON.stringify(labels.map(label =>
  label.replace(asciiWhitespace, '').replace(asciiUppercase, letter => letter.toLowerCase())
)));
