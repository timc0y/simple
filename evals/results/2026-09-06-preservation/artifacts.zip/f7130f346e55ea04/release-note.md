# Release v2.4.0

Run `npm test` before deploying. Deploy with `npm run deploy -- v2.4.0`. If rollback is needed, the rollback boundary is before database migration starts. Migration duration is unknown.
