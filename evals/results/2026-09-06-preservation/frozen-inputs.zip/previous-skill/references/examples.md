# Worked examples

Use a worked example to make a decision rule concrete. Change one material fact and
show when the recommendation changes. Keep examples synthetic; repository evidence
still decides the real case.

## Filter before ranking

An importer may choose one of several destinations. If a destination is usable only
after its credentials and schema pass validation, filter first, then rank the usable
destinations. Ranking all destinations can select one that cannot accept the data.

If the ranking service itself checks credentials and schema and returns only usable
destinations, ranking first is sufficient. The changed fact removes the missing
precondition, so the recommendation reverses.

## Preserve domain meaning in shared storage

Two records use the same table. A missing durable mutation record means the outcome
is unknown and must be resolved before another mutation. An expired offer means the
offer is no longer valid and may be replaced under the product's normal rules. Shared
storage does not make those states interchangeable.

If both records are governed by the same lifecycle and recovery rule, one record type
may be enough. The changed domain fact justifies consolidation; the storage mechanism
alone does not.

## Informal wording is not an API contract

A guide says, “run a check before release,” and the command is renamed from `check` to
`verify`. Keep the prose natural; it does not require an alias. If users or scripts
invoke the published command `check`, retain a bounded compatibility alias or migrate
those callers first.

If the old command was never published and has no consumer or retained-state
obligation, delete it. The changed
contract fact reverses the compatibility recommendation.

## Correct one premise, preserve the rest

A plan assumes the input is local and recommends a direct file edit. If the input is
actually remote, replace that step with the supported fetch path. Keep the existing
format, validation, and proof requirements unless the correction also changes them.

If the corrected source has a different format or trust boundary, those requirements
must change too. The scope of the correction determines the scope of the rewrite.

## Reviews can explain a choice

A review request asks why a small adapter is sufficient. Explain the owner, ordinary
path, and missing precondition; do not manufacture defects to fill a defect-hunting
template.

If the request asks whether the adapter has a race, test and report that race. The
changed review purpose adds a proof obligation.

## Supply an address, preserve the owner

A visible nested component reads a document owned by its containing record, but the
supported editor can address only top-level document elements. Bind one hidden native
element to the existing property and use the editor's ordinary path. The component
and record keep ownership.

If the platform cannot bind that element to the property, move the document only when
the new owner and migration proof are explicit. An addressability failure alone does
not justify moving state.

## Add complexity when the constraint is real

A local command processes a few dozen items. A direct loop is enough; a queue and
worker pool add recovery and ownership work without a demonstrated need. If measured
input grows to millions of items and the command must survive process restarts, a
durable queue may earn its cost.

The changed scale and failure consequence create the obligation. A category's usual
architecture does not.

For the underlying engineering precedent about moving complexity behind one owner,
see the [Raptor comparison](https://x.com/SpaceX/status/1819795288116330594) and the
[SpaceX technical disclosure](https://content.spacex.com/cms-assets/FINAL_Documents%20and%20Updates/SpaceX%20-%20EU%20Prospectus%20%28Approved%20by%20Bafin%29%20-%20June%205%2C%202026.pdf).
