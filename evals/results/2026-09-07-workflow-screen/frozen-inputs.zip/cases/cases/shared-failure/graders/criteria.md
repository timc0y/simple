The fix must route both callers through the shared operation's correctness boundary.
After a timeout that may have happened after the write, retrying the same operation
key must leave one effect and return a known applied or already-applied result.
Different keys must each apply once. An unknown result must remain unknown and must
not be reported as applied without evidence. The fix must use the fixture's public
caller and operation interfaces, and must not special-case caller A.
