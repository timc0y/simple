import { cp, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const here = dirname(fileURLToPath(import.meta.url));
const verify = d => spawnSync(process.execPath, [join(here, 'verifier.mjs'), d], { encoding: 'utf8' });
const base = join(here, 'fixture');
const bad = await mkdtemp(join(tmpdir(), 'shared-failure-bad-'));
await cp(base, bad, { recursive: true });
if (verify(bad).status === 0) throw Error('verifier accepted original fixture');
await rm(bad, { recursive: true, force: true });

const good = await mkdtemp(join(tmpdir(), 'shared-failure-good-'));
await cp(base, good, { recursive: true });
const owner = `import { readFile, writeFile } from 'node:fs/promises';
export async function applyOnce(key, file, mode = 'normal') {
  const state = JSON.parse(await readFile(file, 'utf8'));
  if (mode === 'unknown') return { status: 'unknown' };
  if (state.keys.includes(key)) return { status: 'already-applied' };
  state.keys.push(key); state.count += 1;
  await writeFile(file, JSON.stringify(state));
  if (mode === 'timeout-after-write') throw Object.assign(new Error('timeout'), { code: 'TIMEOUT' });
  return { status: 'applied' };
}`;
await writeFile(join(good, 'operation.mjs'), owner);
if (verify(good).status !== 0) throw Error('verifier rejected known-good fixture');

const guard = await mkdtemp(join(tmpdir(), 'shared-failure-guard-'));
await cp(base, guard, { recursive: true });
await writeFile(join(guard, 'caller-a.mjs'), `import { applyOnce } from './operation.mjs';
const key = process.env.OPERATION_KEY ?? 'a';
const result = key === 'shared' && process.env.MODE === 'normal' ? { status: 'already-applied' } : await applyOnce(key, process.env.STATE_FILE, process.env.MODE ?? 'normal');
console.log(JSON.stringify(result));`);
if (verify(guard).status === 0) throw Error('verifier accepted caller-a-only guard');
await rm(guard, { recursive: true, force: true });
await rm(good, { recursive: true, force: true });
console.log('selftest passed');
