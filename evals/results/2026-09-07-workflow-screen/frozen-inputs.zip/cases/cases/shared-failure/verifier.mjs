import { readFile, writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { join, resolve } from 'node:path';

const root = resolve(process.argv[2] ?? '.');
const checks = [];
const check = (id, passed, detail = '') => checks.push({ id, passed: !!passed, detail });
const output = result => { try { return JSON.parse(result.stdout); } catch { return {}; } };
const run = (caller, mode, key) => spawnSync(process.execPath, [join(root, caller)], {
  cwd: root, encoding: 'utf8', env: { ...process.env, STATE_FILE: join(root, 'state.json'), MODE: mode, OPERATION_KEY: key }
});
const reset = async () => writeFile(join(root, 'state.json'), '{"count":0,"keys":[]}');
const state = async () => JSON.parse(await readFile(join(root, 'state.json'), 'utf8'));

await reset();
const distinctA = run('caller-a.mjs', 'normal', 'a');
const distinctB = run('caller-b.mjs', 'normal', 'b');
check('distinct-keys', distinctA.status === 0 && distinctB.status === 0 && JSON.stringify(await state()) === JSON.stringify({ count: 2, keys: ['a', 'b'] }));

await reset();
const first = run('caller-a.mjs', 'timeout-after-write', 'shared');
const retry = run('caller-b.mjs', 'normal', 'shared');
check('timeout-cross-entry-retry', first.status !== 0 && retry.status === 0 && ['applied', 'already-applied'].includes(output(retry).status) && JSON.stringify(await state()) === JSON.stringify({ count: 1, keys: ['shared'] }));

await reset();
const siblingFirst = run('caller-b.mjs', 'timeout-after-write', 'sibling');
const siblingRetry = run('caller-a.mjs', 'normal', 'sibling');
check('sibling-cross-entry-retry', siblingFirst.status !== 0 && siblingRetry.status === 0 && JSON.stringify(await state()) === JSON.stringify({ count: 1, keys: ['sibling'] }));

await reset();
const unknown = run('caller-a.mjs', 'unknown', 'uncertain');
check('unknown-outcome', unknown.status === 0 && output(unknown).status === 'unknown' && JSON.stringify(await state()) === JSON.stringify({ count: 0, keys: [] }));

const report = { passed: checks.every(c => c.passed), checks };
console.log(JSON.stringify(report));
if (process.argv[3]) await writeFile(resolve(process.argv[3]), JSON.stringify(report));
if (!report.passed) process.exit(1);
